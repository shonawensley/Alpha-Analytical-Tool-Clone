# Digit-Reduction Performance Summary

## Aggregate
- Hit@1: 0.00% · Hit@3: 0.00% · Hit@3 (VTRAC): 0.00% · MRR: 0.016

## By State / Variant
- Connecticut4 EVENING: Hit@1 0%, Hit@3 0%, Hit@3 (VTRAC) 0%, MRR 0.06, Samples 1, Misses 0
- Connecticut4 MIDDAY: Hit@1 0%, Hit@3 0%, Hit@3 (VTRAC) 0%, MRR 0.01, Samples 1, Misses 0
- Delaware4 EVENING: Hit@1 0%, Hit@3 0%, Hit@3 (VTRAC) 0%, MRR 0.00, Samples 1, Misses 1
- Delaware4 MIDDAY: Hit@1 0%, Hit@3 0%, Hit@3 (VTRAC) 0%, MRR 0.07, Samples 1, Misses 0
- Florida4 EVENING: Hit@1 0%, Hit@3 0%, Hit@3 (VTRAC) 0%, MRR 0.02, Samples 1, Misses 0
- Florida4 MIDDAY: Hit@1 0%, Hit@3 0%, Hit@3 (VTRAC) 0%, MRR 0.00, Samples 1, Misses 1
- Indiana4 EVENING: Hit@1 0%, Hit@3 0%, Hit@3 (VTRAC) 0%, MRR 0.00, Samples 1, Misses 1
- Indiana4 MIDDAY: Hit@1 0%, Hit@3 0%, Hit@3 (VTRAC) 0%, MRR 0.01, Samples 1, Misses 0
- Michigan4 EVENING: Hit@1 0%, Hit@3 0%, Hit@3 (VTRAC) 0%, MRR 0.06, Samples 1, Misses 0
- Michigan4 MIDDAY: Hit@1 0%, Hit@3 0%, Hit@3 (VTRAC) 0%, MRR 0.00, Samples 1, Misses 1
- NewJersey4 EVENING: Hit@1 0%, Hit@3 0%, Hit@3 (VTRAC) 0%, MRR 0.01, Samples 1, Misses 0
- NewJersey4 MIDDAY: Hit@1 0%, Hit@3 0%, Hit@3 (VTRAC) 0%, MRR 0.00, Samples 1, Misses 1
- NewYork4 EVENING: Hit@1 0%, Hit@3 0%, Hit@3 (VTRAC) 0%, MRR 0.00, Samples 1, Misses 1
- NewYork4 MIDDAY: Hit@1 0%, Hit@3 0%, Hit@3 (VTRAC) 0%, MRR 0.00, Samples 1, Misses 1
- Ohio4 EVENING: Hit@1 0%, Hit@3 0%, Hit@3 (VTRAC) 0%, MRR 0.00, Samples 1, Misses 1
- Ohio4 MIDDAY: Hit@1 0%, Hit@3 0%, Hit@3 (VTRAC) 0%, MRR 0.03, Samples 1, Misses 0