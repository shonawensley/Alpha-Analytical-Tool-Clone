# Digit-Reduction Performance Summary

## Aggregate
- Hit@1: 0.00% · Hit@3: 6.25% · Hit@3 (VTRAC): 6.25% · MRR: 0.056

## By State / Variant
- Connecticut4 EVENING: Hit@1 0%, Hit@3 0%, Hit@3 (VTRAC) 0%, MRR 0.17, Samples 1, Misses 0
- Connecticut4 MIDDAY: Hit@1 0%, Hit@3 0%, Hit@3 (VTRAC) 0%, MRR 0.01, Samples 1, Misses 0
- Delaware4 EVENING: Hit@1 0%, Hit@3 0%, Hit@3 (VTRAC) 0%, MRR 0.00, Samples 1, Misses 1
- Delaware4 MIDDAY: Hit@1 0%, Hit@3 100%, Hit@3 (VTRAC) 100%, MRR 0.33, Samples 1, Misses 0
- Florida4 EVENING: Hit@1 0%, Hit@3 0%, Hit@3 (VTRAC) 0%, MRR 0.01, Samples 1, Misses 0
- Florida4 MIDDAY: Hit@1 0%, Hit@3 0%, Hit@3 (VTRAC) 0%, MRR 0.00, Samples 1, Misses 1
- Indiana4 EVENING: Hit@1 0%, Hit@3 0%, Hit@3 (VTRAC) 0%, MRR 0.00, Samples 1, Misses 1
- Indiana4 MIDDAY: Hit@1 0%, Hit@3 0%, Hit@3 (VTRAC) 0%, MRR 0.01, Samples 1, Misses 0
- Michigan4 EVENING: Hit@1 0%, Hit@3 0%, Hit@3 (VTRAC) 0%, MRR 0.25, Samples 1, Misses 0
- Michigan4 MIDDAY: Hit@1 0%, Hit@3 0%, Hit@3 (VTRAC) 0%, MRR 0.00, Samples 1, Misses 1
- NewJersey4 EVENING: Hit@1 0%, Hit@3 0%, Hit@3 (VTRAC) 0%, MRR 0.01, Samples 1, Misses 0
- NewJersey4 MIDDAY: Hit@1 0%, Hit@3 0%, Hit@3 (VTRAC) 0%, MRR 0.00, Samples 1, Misses 1
- NewYork4 EVENING: Hit@1 0%, Hit@3 0%, Hit@3 (VTRAC) 0%, MRR 0.00, Samples 1, Misses 1
- NewYork4 MIDDAY: Hit@1 0%, Hit@3 0%, Hit@3 (VTRAC) 0%, MRR 0.00, Samples 1, Misses 1
- Ohio4 EVENING: Hit@1 0%, Hit@3 0%, Hit@3 (VTRAC) 0%, MRR 0.00, Samples 1, Misses 1
- Ohio4 MIDDAY: Hit@1 0%, Hit@3 0%, Hit@3 (VTRAC) 0%, MRR 0.11, Samples 1, Misses 0