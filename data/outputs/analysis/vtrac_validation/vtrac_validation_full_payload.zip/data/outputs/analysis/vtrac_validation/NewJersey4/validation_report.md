# V-TRAC Validation Report -- NewJersey4
_Generated: 2025-11-16T07:20:09.690427Z_

**Winners HTML files considered (newest first):**
- data/outputs/analysis/winners/2025-06-26/NewJersey4/NewJersey4_vtrac7_winner_756_20251116_021934.html
- data/outputs/analysis/winners/2025-06-26/NewJersey4/NewJersey4_vtrac24_winner_819_20251116_021933.html

**Analyzer global top straights (per source):**
- primary: 867, 687, 786, 817, 871, 068, 718, 218

## Midday
- Hot cells: **8**, Super-hot: **12**
- Consensus col1: **True**, col2: **False**
- Stable columns (>=3/4 rows share a 3-value V-TRAC signature): `3,2`
- Top V-TRAC box signatures in Set1/Draw1 cells: `V2x2_1x1_4x1, V2x2_1x1`
- Analyzer <-> Winners overlaps by source:
  - primary: **2** -> V2x2_1x1, V2x2_1x1_4x1
- Analyzer metrics:
  - primary: indices=26 mask_drop=20 reduction_hits=117 mirror_supported=22 double_hits=744
    straights: 867(22.36), 687(20.70), 786(16.04), 817(15.31), 871(14.83), 068(14.69)
    straight overlap: **0** -> --

## Evening
- Hot cells: **8**, Super-hot: **12**
- Consensus col1: **True**, col2: **False**
- Stable columns (>=3/4 rows share a 3-value V-TRAC signature): `none`
- Top V-TRAC box signatures in Set1/Draw1 cells: `none`
- Analyzer <-> Winners overlaps by source:
  - primary: **0** -> --
- Analyzer metrics:
  - primary: indices=23 mask_drop=19 reduction_hits=118 mirror_supported=18 double_hits=762
    straights: 867(22.36), 687(20.70), 786(16.04), 817(15.31), 871(14.83), 068(14.69)
    straight overlap: **0** -> --

## Combined
- Hot cells: **8**, Super-hot: **12**
- Consensus col1: **False**, col2: **False**
- Stable columns (>=3/4 rows share a 3-value V-TRAC signature): `5,4,3,2,1`
- Top V-TRAC box signatures in Set1/Draw1 cells: `V2x2_3x2_4x1, V2x3_3x3_4x2, V2x2_3x2, V2x2_3x1`
- Analyzer <-> Winners overlaps by source:
  - primary: **4** -> V2x2_3x1, V2x2_3x2, V2x2_3x2_4x1, V2x3_3x3_4x2
- Analyzer metrics:
  - primary: indices=21 mask_drop=16 reduction_hits=99 mirror_supported=17 double_hits=699
    straights: 867(22.36), 687(20.70), 786(16.04), 817(15.31), 871(14.83), 068(14.69)
    straight overlap: **0** -> --
