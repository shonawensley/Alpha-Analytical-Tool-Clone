# V-TRAC Validation Report -- NewYork4
_Generated: 2025-11-16T07:20:10.045772Z_

**Winners HTML files considered (newest first):**
- data/outputs/analysis/winners/2025-06-26/NewYork4/NewYork4_vtrac31_winner_924_20251116_021936.html
- data/outputs/analysis/winners/2025-06-26/NewYork4/NewYork4_vtrac22_winner_142_20251116_021935.html

**Analyzer global top straights (per source):**
- primary: 964, 194, 416, 619, 641, 406, 604, 864

## Midday
- Hot cells: **8**, Super-hot: **12**
- Consensus col1: **False**, col2: **False**
- Stable columns (>=3/4 rows share a 3-value V-TRAC signature): `2,1`
- Top V-TRAC box signatures in Set1/Draw1 cells: `V2x2_4x1_5x1`
- Analyzer <-> Winners overlaps by source:
  - primary: **1** -> V2x2_4x1_5x1
- Analyzer metrics:
  - primary: indices=14 mask_drop=14 reduction_hits=194 mirror_supported=7 double_hits=354
    straights: 964(22.26), 194(20.59), 416(11.56), 619(10.82), 641(8.93), 406(4.36)
    straight overlap: **0** -> --

## Evening
- Hot cells: **8**, Super-hot: **12**
- Consensus col1: **False**, col2: **False**
- Stable columns (>=3/4 rows share a 3-value V-TRAC signature): `3,2,1`
- Top V-TRAC box signatures in Set1/Draw1 cells: `V3x2_5x2_1x1, V3x2_1x1_5x1`
- Analyzer <-> Winners overlaps by source:
  - primary: **2** -> V3x2_1x1_5x1, V3x2_5x2_1x1
- Analyzer metrics:
  - primary: indices=12 mask_drop=11 reduction_hits=140 mirror_supported=11 double_hits=266
    straights: 964(22.26), 194(20.59), 406(4.36), 604(3.81), 864(3.69), 684(3.45)
    straight overlap: **0** -> --

## Combined
- Hot cells: **8**, Super-hot: **12**
- Consensus col1: **False**, col2: **False**
- Stable columns (>=3/4 rows share a 3-value V-TRAC signature): `4,3,2,1`
- Top V-TRAC box signatures in Set1/Draw1 cells: `V5x4_2x1_3x1, V5x4_2x2_3x1, V5x3_2x1_3x1`
- Analyzer <-> Winners overlaps by source:
  - primary: **3** -> V5x3_2x1_3x1, V5x4_2x1_3x1, V5x4_2x2_3x1
- Analyzer metrics:
  - primary: indices=14 mask_drop=14 reduction_hits=202 mirror_supported=9 double_hits=375
    straights: 964(22.26), 194(20.59), 416(11.56), 619(10.82), 641(8.93), 406(4.36)
    straight overlap: **0** -> --
