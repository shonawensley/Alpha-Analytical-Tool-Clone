# V-TRAC Validation Report -- Indiana4
_Generated: 2025-11-16T07:20:08.956534Z_

**Winners HTML files considered (newest first):**
- data/outputs/analysis/winners/2025-06-26/Indiana4/Indiana4_vtrac24_winner_913_20251116_021931.html
- data/outputs/analysis/winners/2025-06-26/Indiana4/Indiana4_vtrac14_winner_340_20251116_021930.html

**Analyzer global top straights (per source):**
- primary: 540, 054, 045, 504, 584, 845, 548, 084

## Midday
- Hot cells: **8**, Super-hot: **12**
- Consensus col1: **True**, col2: **False**
- Stable columns (>=3/4 rows share a 3-value V-TRAC signature): `2`
- Top V-TRAC box signatures in Set1/Draw1 cells: `V2x1_4x1_5x1`
- Analyzer <-> Winners overlaps by source:
  - primary: **1** -> V2x1_4x1_5x1
- Analyzer metrics:
  - primary: indices=19 mask_drop=16 reduction_hits=242 mirror_supported=14 double_hits=344
    straights: 540(17.81), 054(15.33), 045(14.88), 504(14.72), 584(11.94), 845(11.72)
    straight overlap: **0** -> --

## Evening
- Hot cells: **8**, Super-hot: **12**
- Consensus col1: **True**, col2: **False**
- Stable columns (>=3/4 rows share a 3-value V-TRAC signature): `3,2`
- Top V-TRAC box signatures in Set1/Draw1 cells: `V3x3_4x1_5x1, V3x3_5x1`
- Analyzer <-> Winners overlaps by source:
  - primary: **2** -> V3x3_4x1_5x1, V3x3_5x1
- Analyzer metrics:
  - primary: indices=24 mask_drop=19 reduction_hits=263 mirror_supported=19 double_hits=328
    straights: 540(17.81), 054(15.33), 045(14.88), 504(14.72), 584(11.94), 845(11.72)
    straight overlap: **0** -> --

## Combined
- Hot cells: **8**, Super-hot: **12**
- Consensus col1: **True**, col2: **False**
- Stable columns (>=3/4 rows share a 3-value V-TRAC signature): `2`
- Top V-TRAC box signatures in Set1/Draw1 cells: `V1x1_3x1_4x1`
- Analyzer <-> Winners overlaps by source:
  - primary: **1** -> V1x1_3x1_4x1
- Analyzer metrics:
  - primary: indices=13 mask_drop=13 reduction_hits=198 mirror_supported=12 double_hits=246
    straights: 540(17.81), 054(15.33), 045(14.88), 504(14.72), 584(11.94), 845(11.72)
    straight overlap: **0** -> --
