# V-TRAC Validation Report -- Delaware4
_Generated: 2025-11-16T07:20:08.241641Z_

**Winners HTML files considered (newest first):**
- data/outputs/analysis/winners/2025-06-26/Delaware4/Delaware4_vtrac20_winner_771_20251116_021929.html
- data/outputs/analysis/winners/2025-06-26/Delaware4/Delaware4_vtrac30_winner_487_20251116_021928.html
- data/outputs/analysis/winners/2025-06-26/Delaware4/Delaware4_vtrac20_winner_771_20251115_044049.html
- data/outputs/analysis/winners/2025-06-26/Delaware4/Delaware4_vtrac30_winner_487_20251115_044048.html

**Analyzer global top straights (per source):**
- primary: 013, 386, 138, 683, 836, 183, 831, 063

## Midday
- Hot cells: **8**, Super-hot: **12**
- Consensus col1: **False**, col2: **False**
- Stable columns (>=3/4 rows share a 3-value V-TRAC signature): `2,1`
- Top V-TRAC box signatures in Set1/Draw1 cells: `V2x1_3x1_5x1`
- Analyzer <-> Winners overlaps by source:
  - primary: **1** -> V2x1_3x1_5x1
- Analyzer metrics:
  - primary: indices=18 mask_drop=14 reduction_hits=127 mirror_supported=18 double_hits=518
    straights: 013(28.64), 386(22.71), 138(22.67), 683(21.93), 836(19.88), 183(19.50)
    straight overlap: **0** -> --

## Evening
- Hot cells: **8**, Super-hot: **12**
- Consensus col1: **False**, col2: **False**
- Stable columns (>=3/4 rows share a 3-value V-TRAC signature): `5,4,3,2,1`
- Top V-TRAC box signatures in Set1/Draw1 cells: `V4x4_5x2, V4x3, V4x4_5x3_2x1`
- Analyzer <-> Winners overlaps by source:
  - primary: **3** -> V4x3, V4x4_5x2, V4x4_5x3_2x1
- Analyzer metrics:
  - primary: indices=15 mask_drop=12 reduction_hits=116 mirror_supported=15 double_hits=570
    straights: 013(28.64), 386(22.71), 138(22.67), 683(21.93), 836(19.88), 183(19.50)
    straight overlap: **0** -> --

## Combined
- Hot cells: **8**, Super-hot: **12**
- Consensus col1: **False**, col2: **False**
- Stable columns (>=3/4 rows share a 3-value V-TRAC signature): `3,2,1`
- Top V-TRAC box signatures in Set1/Draw1 cells: `V2x2_4x2_1x1, V4x2_1x1_2x1`
- Analyzer <-> Winners overlaps by source:
  - primary: **2** -> V2x2_4x2_1x1, V4x2_1x1_2x1
- Analyzer metrics:
  - primary: indices=19 mask_drop=15 reduction_hits=128 mirror_supported=19 double_hits=615
    straights: 013(28.64), 386(22.71), 138(22.67), 683(21.93), 836(19.88), 183(19.50)
    straight overlap: **0** -> --
