# V-TRAC Validation Report -- Michigan4
_Generated: 2025-10-23T06:07:31.984793Z_

**Winners HTML files considered (newest first):**
- data/outputs/analysis/winners/Michigan4/Michigan4_vtrac33_winner_339_20251023_020627.html
- data/outputs/analysis/winners/Michigan4/Michigan4_vtrac18_winner_618_20251023_020626.html

**Analyzer global top straights (per source):**
- primary: 087, 708, 547, 870, 847, 752, 084, 527

## Midday
- Hot cells: **8**, Super-hot: **12**
- Consensus col1: **False**, col2: **False**
- Stable columns (>=3/4 rows share a 3-value V-TRAC signature): `4,3,2,1`
- Top V-TRAC box signatures in Set1/Draw1 cells: `V3x2_1x1, V3x3_1x1_5x1, V3x3_1x1`
- Analyzer <-> Winners overlaps by source:
  - primary: **3** -> V3x2_1x1, V3x3_1x1, V3x3_1x1_5x1
- Analyzer metrics:
  - primary: indices=20 mask_drop=19 reduction_hits=184 mirror_supported=18 double_hits=390
    straights: 547(14.27), 847(12.76), 752(12.49), 527(12.09), 702(11.99), 257(11.87)
    straight overlap: **0** -> --

## Evening
- Hot cells: **8**, Super-hot: **12**
- Consensus col1: **True**, col2: **False**
- Stable columns (>=3/4 rows share a 3-value V-TRAC signature): `2`
- Top V-TRAC box signatures in Set1/Draw1 cells: `V1x1_3x1_5x1`
- Analyzer <-> Winners overlaps by source:
  - primary: **1** -> V1x1_3x1_5x1
- Analyzer metrics:
  - primary: indices=23 mask_drop=22 reduction_hits=236 mirror_supported=20 double_hits=390
    straights: 087(16.79), 708(15.08), 547(14.27), 870(13.53), 847(12.76), 752(12.49)
    straight overlap: **0** -> --

## Combined
- Hot cells: **8**, Super-hot: **12**
- Consensus col1: **True**, col2: **False**
- Stable columns (>=3/4 rows share a 3-value V-TRAC signature): `2`
- Top V-TRAC box signatures in Set1/Draw1 cells: `V3x1_4x1_5x1`
- Analyzer <-> Winners overlaps by source:
  - primary: **1** -> V3x1_4x1_5x1
- Analyzer metrics:
  - primary: indices=23 mask_drop=20 reduction_hits=206 mirror_supported=21 double_hits=331
    straights: 087(16.79), 708(15.08), 547(14.27), 870(13.53), 847(12.76), 752(12.49)
    straight overlap: **0** -> --
