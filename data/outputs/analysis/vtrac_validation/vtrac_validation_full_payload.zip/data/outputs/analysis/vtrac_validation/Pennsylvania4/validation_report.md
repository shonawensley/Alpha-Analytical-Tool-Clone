# V-TRAC Validation Report -- Pennsylvania4
_Generated: 2025-11-16T07:20:11.481771Z_

**Winners HTML files considered (newest first):**
- data/outputs/analysis/winners/2025-06-26/Pennsylvania4/Pennsylvania4_vtrac27_winner_773_20251116_021939.html
- data/outputs/analysis/winners/2025-06-26/Pennsylvania4/Pennsylvania4_vtrac23_winner_886_20251116_021939.html

**Analyzer global top straights (per source):**
- primary: 018, 208, 201, 871, 817, 687, 810, 081

## Midday
- Hot cells: **8**, Super-hot: **12**
- Consensus col1: **True**, col2: **False**
- Stable columns (>=3/4 rows share a 3-value V-TRAC signature): `2`
- Top V-TRAC box signatures in Set1/Draw1 cells: `V3x2_4x1_5x1`
- Analyzer <-> Winners overlaps by source:
  - primary: **1** -> V3x2_4x1_5x1
- Analyzer metrics:
  - primary: indices=26 mask_drop=19 reduction_hits=170 mirror_supported=26 double_hits=397
    straights: 018(20.75), 208(13.02), 201(12.80), 871(11.65), 817(11.65), 687(11.34)
    straight overlap: **0** -> --

## Evening
- Hot cells: **8**, Super-hot: **12**
- Consensus col1: **False**, col2: **False**
- Stable columns (>=3/4 rows share a 3-value V-TRAC signature): `3,2,1`
- Top V-TRAC box signatures in Set1/Draw1 cells: `V4x2_2x1, V4x3_1x1_2x1`
- Analyzer <-> Winners overlaps by source:
  - primary: **2** -> V4x2_2x1, V4x3_1x1_2x1
- Analyzer metrics:
  - primary: indices=20 mask_drop=17 reduction_hits=161 mirror_supported=20 double_hits=334
    straights: 018(20.75), 208(13.02), 201(12.80), 871(11.65), 817(11.65), 687(11.34)
    straight overlap: **0** -> --

## Combined
- Hot cells: **8**, Super-hot: **12**
- Consensus col1: **True**, col2: **True**
- Stable columns (>=3/4 rows share a 3-value V-TRAC signature): `3`
- Top V-TRAC box signatures in Set1/Draw1 cells: `V5x2_2x1_4x1`
- Analyzer <-> Winners overlaps by source:
  - primary: **1** -> V5x2_2x1_4x1
- Analyzer metrics:
  - primary: indices=23 mask_drop=17 reduction_hits=172 mirror_supported=23 double_hits=393
    straights: 018(20.75), 208(13.02), 201(12.80), 871(11.65), 817(11.65), 687(11.34)
    straight overlap: **0** -> --
