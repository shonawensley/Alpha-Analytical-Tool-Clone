# V-TRAC Validation Report -- Connecticut4
_Generated: 2025-11-16T07:20:07.888496Z_

**Winners HTML files considered (newest first):**
- data/outputs/analysis/winners/2025-06-26/Connecticut4/Connecticut4_vtrac17_winner_612_20251116_021928.html
- data/outputs/analysis/winners/2025-06-26/Connecticut4/Connecticut4_vtrac30_winner_928_20251116_021927.html
- data/outputs/analysis/winners/2025-06-26/Connecticut4/Connecticut4_vtrac17_winner_612_20251115_044048.html
- data/outputs/analysis/winners/2025-06-26/Connecticut4/Connecticut4_vtrac30_winner_928_20251115_044047.html

**Analyzer global top straights (per source):**
- primary: 683, 386, 836, 834, 183, 813, 138, 438

## Midday
- Hot cells: **8**, Super-hot: **12**
- Consensus col1: **False**, col2: **False**
- Stable columns (>=3/4 rows share a 3-value V-TRAC signature): `4,3,2,1`
- Top V-TRAC box signatures in Set1/Draw1 cells: `V3x2_1x1, V1x3_3x2`
- Analyzer <-> Winners overlaps by source:
  - primary: **2** -> V1x3_3x2, V3x2_1x1
- Analyzer metrics:
  - primary: indices=15 mask_drop=15 reduction_hits=107 mirror_supported=7 double_hits=424
    straights: 683(12.97), 386(12.42), 836(11.13), 834(11.08), 183(10.91), 813(10.45)
    straight overlap: **0** -> --

## Evening
- Hot cells: **8**, Super-hot: **12**
- Consensus col1: **False**, col2: **False**
- Stable columns (>=3/4 rows share a 3-value V-TRAC signature): `3,2,1`
- Top V-TRAC box signatures in Set1/Draw1 cells: `V5x2_2x1, V4x2_5x2_2x1`
- Analyzer <-> Winners overlaps by source:
  - primary: **2** -> V4x2_5x2_2x1, V5x2_2x1
- Analyzer metrics:
  - primary: indices=16 mask_drop=14 reduction_hits=96 mirror_supported=9 double_hits=525
    straights: 683(12.97), 386(12.42), 836(11.13), 834(11.08), 183(10.91), 813(10.45)
    straight overlap: **0** -> --

## Combined
- Hot cells: **8**, Super-hot: **12**
- Consensus col1: **False**, col2: **False**
- Stable columns (>=3/4 rows share a 3-value V-TRAC signature): `3,2,1`
- Top V-TRAC box signatures in Set1/Draw1 cells: `V5x2_2x1_3x1`
- Analyzer <-> Winners overlaps by source:
  - primary: **1** -> V5x2_2x1_3x1
- Analyzer metrics:
  - primary: indices=14 mask_drop=13 reduction_hits=91 mirror_supported=6 double_hits=428
    straights: 683(12.97), 386(12.42), 836(11.13), 834(11.08), 183(10.91), 813(10.45)
    straight overlap: **0** -> --
