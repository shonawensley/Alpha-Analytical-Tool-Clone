# V-TRAC Validation Report -- Connecticut4
_Generated: 2025-10-23T06:07:30.602898Z_

**Winners HTML files considered (newest first):**
- data/outputs/analysis/winners/Connecticut4/Connecticut4_vtrac5_winner_059_20251023_020624.html
- data/outputs/analysis/winners/Connecticut4/Connecticut4_vtrac34_winner_894_20251023_020623.html

**Analyzer global top straights (per source):**
- primary: 507, 705, 250, 052, 702, 207, 054, 867

## Midday
- Hot cells: **8**, Super-hot: **12**
- Consensus col1: **False**, col2: **False**
- Stable columns (>=3/4 rows share a 3-value V-TRAC signature): `5,4,3,2,1`
- Top V-TRAC box signatures in Set1/Draw1 cells: `V3x2_1x1, V1x4_3x2_5x1, V1x3_3x2_5x1, V1x3_3x2`
- Analyzer <-> Winners overlaps by source:
  - primary: **4** -> V1x3_3x2, V1x3_3x2_5x1, V1x4_3x2_5x1, V3x2_1x1
- Analyzer metrics:
  - primary: indices=14 mask_drop=12 reduction_hits=206 mirror_supported=12 double_hits=386
    straights: 507(17.14), 705(16.58), 250(10.67), 052(10.66), 702(6.21), 207(6.13)
    straight overlap: **0** -> --

## Evening
- Hot cells: **8**, Super-hot: **12**
- Consensus col1: **False**, col2: **False**
- Stable columns (>=3/4 rows share a 3-value V-TRAC signature): `5,4,3,2,1`
- Top V-TRAC box signatures in Set1/Draw1 cells: `V2x4_4x2_5x2, V2x3_4x2_5x2, V2x2_5x2_4x1, V5x2_2x1_4x1, V5x2_2x1`
- Analyzer <-> Winners overlaps by source:
  - primary: **5** -> V2x2_5x2_4x1, V2x3_4x2_5x2, V2x4_4x2_5x2, V5x2_2x1, V5x2_2x1_4x1
- Analyzer metrics:
  - primary: indices=23 mask_drop=17 reduction_hits=306 mirror_supported=22 double_hits=576
    straights: 507(17.14), 705(16.58), 250(10.67), 052(10.66), 702(6.21), 207(6.13)
    straight overlap: **0** -> --

## Combined
- Hot cells: **8**, Super-hot: **12**
- Consensus col1: **True**, col2: **False**
- Stable columns (>=3/4 rows share a 3-value V-TRAC signature): `5,4,3,2`
- Top V-TRAC box signatures in Set1/Draw1 cells: `V5x3_1x2_4x2, V4x2_5x2_1x1, V4x2_5x2, V5x2_4x1`
- Analyzer <-> Winners overlaps by source:
  - primary: **4** -> V4x2_5x2, V4x2_5x2_1x1, V5x2_4x1, V5x3_1x2_4x2
- Analyzer metrics:
  - primary: indices=22 mask_drop=19 reduction_hits=316 mirror_supported=22 double_hits=550
    straights: 507(17.14), 705(16.58), 250(10.67), 052(10.66), 054(3.27), 867(2.84)
    straight overlap: **0** -> --
