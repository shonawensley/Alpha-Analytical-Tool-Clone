# V-TRAC Validation Report -- Virginia4
_Generated: 2025-11-16T07:20:12.552411Z_

**Winners HTML files considered (newest first):**
- data/outputs/analysis/winners/2025-06-26/Virginia4/Virginia4_vtrac6_winner_165_20251116_021943.html
- data/outputs/analysis/winners/2025-06-26/Virginia4/Virginia4_vtrac29_winner_328_20251116_021942.html

**Analyzer global top straights (per source):**
- primary: 540, 504, 045, 524, 407, 705, 047, 704

## Midday
- Hot cells: **8**, Super-hot: **12**
- Consensus col1: **False**, col2: **False**
- Stable columns (>=3/4 rows share a 3-value V-TRAC signature): `4,3,2,1`
- Top V-TRAC box signatures in Set1/Draw1 cells: `V1x3_3x2_5x2, V1x3_3x2_5x1, V1x3_3x1, V1x3`
- Analyzer <-> Winners overlaps by source:
  - primary: **4** -> V1x3, V1x3_3x1, V1x3_3x2_5x1, V1x3_3x2_5x2
- Analyzer metrics:
  - primary: indices=13 mask_drop=11 reduction_hits=225 mirror_supported=7 double_hits=538
    straights: 540(36.14), 504(35.61), 045(34.68), 524(24.33), 407(18.41), 705(18.36)
    straight overlap: **0** -> --

## Evening
- Hot cells: **8**, Super-hot: **12**
- Consensus col1: **False**, col2: **False**
- Stable columns (>=3/4 rows share a 3-value V-TRAC signature): `2,1`
- Top V-TRAC box signatures in Set1/Draw1 cells: `V1x2_4x1_5x1, V1x2_5x1`
- Analyzer <-> Winners overlaps by source:
  - primary: **2** -> V1x2_4x1_5x1, V1x2_5x1
- Analyzer metrics:
  - primary: indices=14 mask_drop=13 reduction_hits=256 mirror_supported=5 double_hits=478
    straights: 540(36.14), 504(35.61), 045(34.68), 524(24.33), 407(18.41), 705(18.36)
    straight overlap: **0** -> --

## Combined
- Hot cells: **8**, Super-hot: **12**
- Consensus col1: **False**, col2: **False**
- Stable columns (>=3/4 rows share a 3-value V-TRAC signature): `4,3,2,1`
- Top V-TRAC box signatures in Set1/Draw1 cells: `V1x2_3x1_5x1`
- Analyzer <-> Winners overlaps by source:
  - primary: **1** -> V1x2_3x1_5x1
- Analyzer metrics:
  - primary: indices=15 mask_drop=13 reduction_hits=246 mirror_supported=7 double_hits=523
    straights: 540(36.14), 504(35.61), 045(34.68), 524(24.33), 407(18.41), 705(18.36)
    straight overlap: **0** -> --
