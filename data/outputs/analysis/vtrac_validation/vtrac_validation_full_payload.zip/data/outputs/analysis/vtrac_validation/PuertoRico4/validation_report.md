# V-TRAC Validation Report -- PuertoRico4
_Generated: 2025-11-16T07:20:11.840178Z_

**Winners HTML files considered (newest first):**
- data/outputs/analysis/winners/2025-06-26/PuertoRico4/PuertoRico4_vtrac22_winner_467_20251116_021941.html
- data/outputs/analysis/winners/2025-06-26/PuertoRico4/PuertoRico4_vtrac11_winner_087_20251116_021940.html

**Analyzer global top straights (per source):**
- primary: 024, 240, 092, 047, 924, 204, 407, 290

## Midday
- Hot cells: **8**, Super-hot: **12**
- Consensus col1: **True**, col2: **True**
- Stable columns (>=3/4 rows share a 3-value V-TRAC signature): `4`
- Top V-TRAC box signatures in Set1/Draw1 cells: `V1x1_2x1_4x1`
- Analyzer <-> Winners overlaps by source:
  - primary: **1** -> V1x1_2x1_4x1
- Analyzer metrics:
  - primary: indices=10 mask_drop=10 reduction_hits=145 mirror_supported=5 double_hits=414
    straights: 024(43.77), 240(32.68), 092(28.92), 047(28.19), 924(27.62), 204(26.98)
    straight overlap: **0** -> --

## Evening
- Hot cells: **8**, Super-hot: **12**
- Consensus col1: **False**, col2: **False**
- Stable columns (>=3/4 rows share a 3-value V-TRAC signature): `2,1`
- Top V-TRAC box signatures in Set1/Draw1 cells: `V5x3_1x2_3x2`
- Analyzer <-> Winners overlaps by source:
  - primary: **1** -> V5x3_1x2_3x2
- Analyzer metrics:
  - primary: indices=14 mask_drop=13 reduction_hits=154 mirror_supported=7 double_hits=562
    straights: 024(43.77), 240(32.68), 092(28.92), 047(28.19), 924(27.62), 204(26.98)
    straight overlap: **0** -> --

## Combined
- Hot cells: **8**, Super-hot: **12**
- Consensus col1: **False**, col2: **False**
- Stable columns (>=3/4 rows share a 3-value V-TRAC signature): `3,2,1`
- Top V-TRAC box signatures in Set1/Draw1 cells: `V3x2_1x1_5x1, V1x2_3x2_5x1`
- Analyzer <-> Winners overlaps by source:
  - primary: **2** -> V1x2_3x2_5x1, V3x2_1x1_5x1
- Analyzer metrics:
  - primary: indices=14 mask_drop=13 reduction_hits=154 mirror_supported=7 double_hits=562
    straights: 024(43.77), 240(32.68), 092(28.92), 047(28.19), 924(27.62), 204(26.98)
    straight overlap: **0** -> --
