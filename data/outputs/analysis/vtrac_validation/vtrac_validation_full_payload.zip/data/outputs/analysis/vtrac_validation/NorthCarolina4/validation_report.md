# V-TRAC Validation Report -- NorthCarolina4
_Generated: 2025-11-16T07:20:10.403610Z_

**Winners HTML files considered (newest first):**
- data/outputs/analysis/winners/2025-06-26/NorthCarolina4/NorthCarolina4_vtrac5_winner_400_20251116_021937.html
- data/outputs/analysis/winners/2025-06-26/NorthCarolina4/NorthCarolina4_vtrac5_winner_590_20251116_021936.html

**Analyzer global top straights (per source):**
- primary: 138, 813, 386, 683, 836, 183, 413, 541

## Midday
- Hot cells: **8**, Super-hot: **12**
- Consensus col1: **True**, col2: **True**
- Stable columns (>=3/4 rows share a 3-value V-TRAC signature): `none`
- Top V-TRAC box signatures in Set1/Draw1 cells: `none`
- Analyzer <-> Winners overlaps by source:
  - primary: **0** -> --
- Analyzer metrics:
  - primary: indices=14 mask_drop=9 reduction_hits=91 mirror_supported=13 double_hits=470
    straights: 138(25.99), 813(25.05), 386(23.01), 683(22.58), 836(22.51), 183(21.89)
    straight overlap: **0** -> --

## Evening
- Hot cells: **8**, Super-hot: **12**
- Consensus col1: **False**, col2: **False**
- Stable columns (>=3/4 rows share a 3-value V-TRAC signature): `3,2,1`
- Top V-TRAC box signatures in Set1/Draw1 cells: `V1x2_2x2_5x1, V1x1_2x1_5x1`
- Analyzer <-> Winners overlaps by source:
  - primary: **2** -> V1x1_2x1_5x1, V1x2_2x2_5x1
- Analyzer metrics:
  - primary: indices=24 mask_drop=13 reduction_hits=100 mirror_supported=22 double_hits=689
    straights: 138(25.99), 813(25.05), 386(23.01), 683(22.58), 836(22.51), 183(21.89)
    straight overlap: **0** -> --

## Combined
- Hot cells: **8**, Super-hot: **12**
- Consensus col1: **False**, col2: **False**
- Stable columns (>=3/4 rows share a 3-value V-TRAC signature): `2,1`
- Top V-TRAC box signatures in Set1/Draw1 cells: `V4x3_2x1_5x1, V4x2_5x1`
- Analyzer <-> Winners overlaps by source:
  - primary: **2** -> V4x2_5x1, V4x3_2x1_5x1
- Analyzer metrics:
  - primary: indices=21 mask_drop=12 reduction_hits=79 mirror_supported=19 double_hits=597
    straights: 138(25.99), 813(25.05), 386(23.01), 683(22.58), 836(22.51), 183(21.89)
    straight overlap: **0** -> --
