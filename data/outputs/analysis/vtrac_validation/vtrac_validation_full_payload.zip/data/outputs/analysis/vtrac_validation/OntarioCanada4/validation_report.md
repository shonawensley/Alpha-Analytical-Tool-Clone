# V-TRAC Validation Report -- OntarioCanada4
_Generated: 2025-11-16T07:20:11.117096Z_

**Winners HTML files considered (newest first):**
- data/outputs/analysis/winners/2025-06-26/OntarioCanada4/OntarioCanada4_vtrac3_winner_502_20251116_021939.html
- data/outputs/analysis/winners/2025-06-26/OntarioCanada4/OntarioCanada4_vtrac5_winner_400_20251116_021938.html

**Analyzer global top straights (per source):**
- primary: 594, 940, 059, 094, 590, 095, 945, 934

## Midday
- Hot cells: **8**, Super-hot: **12**
- Consensus col1: **False**, col2: **False**
- Stable columns (>=3/4 rows share a 3-value V-TRAC signature): `2,1`
- Top V-TRAC box signatures in Set1/Draw1 cells: `V5x2_1x1_2x1, V1x1_2x1_5x1`
- Analyzer <-> Winners overlaps by source:
  - primary: **2** -> V1x1_2x1_5x1, V5x2_1x1_2x1
- Analyzer metrics:
  - primary: indices=26 mask_drop=17 reduction_hits=145 mirror_supported=26 double_hits=463
    straights: 594(26.14), 940(21.62), 059(20.54), 094(19.33), 590(18.65), 095(16.53)
    straight overlap: **0** -> --

## Evening
- Hot cells: **8**, Super-hot: **12**
- Consensus col1: **False**, col2: **False**
- Stable columns (>=3/4 rows share a 3-value V-TRAC signature): `3,2,1`
- Top V-TRAC box signatures in Set1/Draw1 cells: `V3x2_5x1, V3x2_1x1_5x1`
- Analyzer <-> Winners overlaps by source:
  - primary: **2** -> V3x2_1x1_5x1, V3x2_5x1
- Analyzer metrics:
  - primary: indices=19 mask_drop=14 reduction_hits=144 mirror_supported=18 double_hits=425
    straights: 594(26.14), 940(21.62), 059(20.54), 094(19.33), 590(18.65), 095(16.53)
    straight overlap: **0** -> --

## Combined
- Hot cells: **8**, Super-hot: **12**
- Consensus col1: **False**, col2: **False**
- Stable columns (>=3/4 rows share a 3-value V-TRAC signature): `4,3,2,1`
- Top V-TRAC box signatures in Set1/Draw1 cells: `V1x2_5x2, V1x3_5x3, V5x3_1x2`
- Analyzer <-> Winners overlaps by source:
  - primary: **3** -> V1x2_5x2, V1x3_5x3, V5x3_1x2
- Analyzer metrics:
  - primary: indices=18 mask_drop=15 reduction_hits=150 mirror_supported=18 double_hits=453
    straights: 594(26.14), 940(21.62), 059(20.54), 094(19.33), 590(18.65), 095(16.53)
    straight overlap: **0** -> --
