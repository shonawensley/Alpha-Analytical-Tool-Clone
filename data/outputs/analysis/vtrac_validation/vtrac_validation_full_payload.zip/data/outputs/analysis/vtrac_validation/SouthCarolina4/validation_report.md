# V-TRAC Validation Report -- SouthCarolina4
_Generated: 2025-11-16T07:20:12.194874Z_

**Winners HTML files considered (newest first):**
- data/outputs/analysis/winners/2025-06-26/SouthCarolina4/SouthCarolina4_vtrac33_winner_933_20251116_021942.html
- data/outputs/analysis/winners/2025-06-26/SouthCarolina4/SouthCarolina4_vtrac10_winner_220_20251116_021942.html

**Analyzer global top straights (per source):**
- primary: 534, 153, 541, 345, 341, 531, 134, 135

## Midday
- Hot cells: **8**, Super-hot: **12**
- Consensus col1: **False**, col2: **False**
- Stable columns (>=3/4 rows share a 3-value V-TRAC signature): `2,1`
- Top V-TRAC box signatures in Set1/Draw1 cells: `V2x2_4x2_1x1`
- Analyzer <-> Winners overlaps by source:
  - primary: **1** -> V2x2_4x2_1x1
- Analyzer metrics:
  - primary: indices=28 mask_drop=23 reduction_hits=208 mirror_supported=26 double_hits=440
    straights: 534(14.31), 153(11.46), 541(9.64), 345(8.51), 341(8.11), 531(7.30)
    straight overlap: **0** -> --

## Evening
- Hot cells: **8**, Super-hot: **12**
- Consensus col1: **True**, col2: **True**
- Stable columns (>=3/4 rows share a 3-value V-TRAC signature): `4,3`
- Top V-TRAC box signatures in Set1/Draw1 cells: `V5x3_4x2_3x1, V4x2_5x2`
- Analyzer <-> Winners overlaps by source:
  - primary: **2** -> V4x2_5x2, V5x3_4x2_3x1
- Analyzer metrics:
  - primary: indices=23 mask_drop=20 reduction_hits=195 mirror_supported=22 double_hits=336
    straights: 534(14.31), 153(11.46), 345(8.51), 531(7.30), 135(6.99), 524(6.84)
    straight overlap: **0** -> --

## Combined
- Hot cells: **8**, Super-hot: **12**
- Consensus col1: **True**, col2: **True**
- Stable columns (>=3/4 rows share a 3-value V-TRAC signature): `none`
- Top V-TRAC box signatures in Set1/Draw1 cells: `none`
- Analyzer <-> Winners overlaps by source:
  - primary: **0** -> --
- Analyzer metrics:
  - primary: indices=19 mask_drop=18 reduction_hits=189 mirror_supported=18 double_hits=319
    straights: 534(14.31), 345(8.51), 341(8.11), 134(7.24), 524(6.84), 175(6.55)
    straight overlap: **0** -> --
