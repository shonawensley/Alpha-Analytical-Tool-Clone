# V-TRAC Validation Report -- Florida4
_Generated: 2025-11-16T07:20:08.603604Z_

**Winners HTML files considered (newest first):**
- data/outputs/analysis/winners/2025-06-26/Florida4/Florida4_vtrac29_winner_337_20251116_021930.html
- data/outputs/analysis/winners/2025-06-26/Florida4/Florida4_vtrac2_winner_100_20251116_021929.html
- data/outputs/analysis/winners/2025-06-26/Florida4/Florida4_vtrac29_winner_337_20251115_044050.html
- data/outputs/analysis/winners/2025-06-26/Florida4/Florida4_vtrac2_winner_100_20251115_044049.html

**Analyzer global top straights (per source):**
- primary: 016, 520, 250, 052, 061, 867, 610, 901

## Midday
- Hot cells: **8**, Super-hot: **12**
- Consensus col1: **True**, col2: **False**
- Stable columns (>=3/4 rows share a 3-value V-TRAC signature): `3,2`
- Top V-TRAC box signatures in Set1/Draw1 cells: `V2x2_1x1_5x1, V2x2_1x1`
- Analyzer <-> Winners overlaps by source:
  - primary: **2** -> V2x2_1x1, V2x2_1x1_5x1
- Analyzer metrics:
  - primary: indices=19 mask_drop=16 reduction_hits=154 mirror_supported=12 double_hits=334
    straights: 016(18.43), 520(15.61), 250(15.39), 052(15.38), 061(14.65), 867(14.46)
    straight overlap: **0** -> --

## Evening
- Hot cells: **8**, Super-hot: **12**
- Consensus col1: **False**, col2: **False**
- Stable columns (>=3/4 rows share a 3-value V-TRAC signature): `3,2,1`
- Top V-TRAC box signatures in Set1/Draw1 cells: `V1x1_3x1_4x1, V1x2_3x1_4x1`
- Analyzer <-> Winners overlaps by source:
  - primary: **2** -> V1x1_3x1_4x1, V1x2_3x1_4x1
- Analyzer metrics:
  - primary: indices=14 mask_drop=13 reduction_hits=147 mirror_supported=8 double_hits=419
    straights: 016(18.43), 520(15.61), 250(15.39), 052(15.38), 061(14.65), 610(13.21)
    straight overlap: **0** -> --

## Combined
- Hot cells: **8**, Super-hot: **12**
- Consensus col1: **False**, col2: **False**
- Stable columns (>=3/4 rows share a 3-value V-TRAC signature): `2,1`
- Top V-TRAC box signatures in Set1/Draw1 cells: `V4x2_2x1_3x1`
- Analyzer <-> Winners overlaps by source:
  - primary: **1** -> V4x2_2x1_3x1
- Analyzer metrics:
  - primary: indices=22 mask_drop=18 reduction_hits=174 mirror_supported=18 double_hits=544
    straights: 016(18.43), 520(15.61), 250(15.39), 052(15.38), 061(14.65), 867(14.46)
    straight overlap: **0** -> --
